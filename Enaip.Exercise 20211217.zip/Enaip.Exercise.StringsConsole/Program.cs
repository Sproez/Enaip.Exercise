﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Enaip.Exercise.StringsConsole
{
    class Program
    {
        static void Main(string[] args)
        {
            // verificare se args contiene qualcosa

            //args = null; //per test eccezione in caso operatore |
            if (args == null || args.Length == 0)
            {
                // informare l'utente 
            }


            //partiamo da args, lo inseriamo in una lista
            // - foreach 
            // (oppure) - ToList 
            // ordineremo la lista - Sort
            // 
            // presenteremo a video (separatore ,), con conteggio "Numero persone: N - "
            // string.Join


        }
    }
}
